#include "good.h"

Good::Good(int quantity) :
    quantity(quantity){};

#include "timeGood.h"

TimeGood::TimeGood(int quantity) :
    Good(quantity){};

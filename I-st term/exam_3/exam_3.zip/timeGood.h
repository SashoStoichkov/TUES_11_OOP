#ifndef TIMEGOOD_H
#define TIMEGOOD_H

#include "good.h"

class TimeGood : public Good{
    public:
        TimeGood(){};

        TimeGood(int quantity);
};

#endif
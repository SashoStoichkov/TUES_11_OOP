#ifndef GOOD_H
#define GOOD_H

class Good{
    // protected:
    public:
        int quantity;

        Good(){};

        Good(int quantity);
};

#endif
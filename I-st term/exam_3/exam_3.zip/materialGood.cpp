#include "materialGood.h"

MaterialGood::MaterialGood(std::string name, std::string meter, int quantity) :
    name(name), meter(meter), Good(quantity){};

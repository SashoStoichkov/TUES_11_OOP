package main.java.com.oop.enums;

public enum EngineType {
    DIESEL, GASOLINE, ELECTRIC, HYBRID
}

package main.java.com.oop.enums;

public enum Model {
    ALPHA_ROMEO, AUDI, BMW, MERCEDES, FERRARI, OPEL
}

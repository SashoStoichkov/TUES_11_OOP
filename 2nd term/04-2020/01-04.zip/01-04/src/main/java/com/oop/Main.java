package main.java.com.oop;

import java.util.List;

public class Main {

    public static void main(String[] args) throws Exception {
        Project project = new Project();
        Staff staff = new Staff("Pesho", "Peshev", Qualification.DEVELOPER);

        project.addStaff(staff);

        Epic epic1 = new Epic("Epic1");
        Story story1 = new Story("Story1.1", staff);
        Task task1 = new Task("Task1.1.1", staff);
        Task task2 = new Task("Task1.1.2", staff);
        Task task3 = new Task("Task1.1.3", staff);

        story1.addTask(task1);
        story1.addTask(task2);
        story1.addTask(task3);
        epic1.addStory(story1);

        Story story2 = new Story("Story1.2", staff);
        Task task12 = new Task("Task1.2.1", staff);
        Task task22 = new Task("Task1.2.2", staff);
        Task task32 = new Task("Task1.2.3", staff);

        story2.addTask(task12);
        story2.addTask(task22);
        story2.addTask(task32);
        epic1.addStory(story2);

        project.addEpic(epic1);

        Epic epic2 = new Epic("Epic2");
        Story story21 = new Story("Story2.1", staff);
        Task task211 = new Task("Task2.1.1", staff);
        Task task212 = new Task("Task2.1.2", staff);

        story21.addTask(task211);
        story21.addTask(task212);
        epic2.addStory(story21);
        project.addEpic(epic2);

        List<Story> stories = project.getAllStories(Status.WAITING, 1);
        for (Story story : stories) {
            System.out.println(story);
        }

        story21.setStatus(Status.IN_PROGRESS);

        stories = project.getAllStories(Status.IN_PROGRESS, 1);
        System.out.println(epic2);

        for (Story story : stories) {
            System.out.println(story);
        }
    }
}

package main.java.com.oop;

public enum Qualification {
    DEVELOPER, QA
}

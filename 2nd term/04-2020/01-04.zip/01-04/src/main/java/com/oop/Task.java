package main.java.com.oop;

public class Task {
    private final Integer id;
    private String name;
    private Status status;
    private String description = "";
    private Staff assignee;
    private static Integer numberTasks = 0;

    public Task(String name, Staff staff) {
        this.id = numberTasks;
        this.name = name;
        this.status = Status.WAITING;
        this.assignee = staff;
        numberTasks++;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Staff getAssignee() {
        return assignee;
    }

    public void setAssignee(Staff assignee) {
        this.assignee = assignee;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", status=" + status +
                ", assignee=" + assignee +
                '}';
    }
}

package main.java.com.oop;

public enum Status {
    WAITING, IN_PROGRESS, DONE
}

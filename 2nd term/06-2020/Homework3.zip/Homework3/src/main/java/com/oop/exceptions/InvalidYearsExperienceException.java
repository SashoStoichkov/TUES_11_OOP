package main.java.com.oop.exceptions;

public class InvalidYearsExperienceException extends Exception {
    public InvalidYearsExperienceException() {
        super("Invalid YearsExperience");
    }
}

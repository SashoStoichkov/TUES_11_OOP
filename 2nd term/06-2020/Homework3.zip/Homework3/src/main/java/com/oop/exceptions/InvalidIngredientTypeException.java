package main.java.com.oop.exceptions;

public class InvalidIngredientTypeException extends Exception {
    public InvalidIngredientTypeException() {
        super("Invalid IngredientType!");
    }
}

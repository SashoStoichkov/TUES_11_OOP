package main.java.com.oop;

public enum IngredientType {
    Dough, Sauce, Vegetable, Cheese, Meat
}

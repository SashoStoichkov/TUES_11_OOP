package main.java.com.oop;

public enum Status {
    OPEN, SHIPPED, COMPLETED, FAILED
}

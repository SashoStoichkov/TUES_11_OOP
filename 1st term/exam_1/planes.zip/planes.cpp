#include <iostream>
using namespace std;

#include <string>
#include <list>

#include <sstream>

class FlightAlreadyInListException : exception {};

class FlightNotInListException : exception {};

class Flight{
    public:
        string flight_number;
        string flight_date;
        string flight_hour;
        bool is_cancelled;
};

bool flightsAreEqual(Flight f1, Flight f2){
    if ((f1.flight_number == f2.flight_number) &&
        (f1.flight_date == f2.flight_date) &&
        (f1.flight_hour == f2.flight_hour)){
        return true;
    } else {
        return false;
    }
}

class FlightSchedule{
    list<Flight> flights;

    public:
        FlightSchedule(){};

        FlightSchedule(list<Flight> flights){
            FlightSchedule::flights = flights;
        }

        list<Flight> getFlights(){
            return flights;
        }

        void addFlight(Flight newFlight){
            list<Flight>::iterator i;

            for (i = flights.begin(); i != flights.end(); i++){
                if (flightsAreEqual(*i, newFlight)){
                    throw FlightAlreadyInListException();
                }
            }

            flights.push_back(newFlight);
        }

        void setCancelled(Flight toCancel){
            list<Flight>::iterator i;

            for (i = flights.begin(); i != flights.end(); i++){
                if (flightsAreEqual(*i, toCancel) == 0){
                    throw FlightNotInListException();
                }
            }

            toCancel.is_cancelled = true;
        }

        list<Flight> findForDate(string date){
            list<Flight> result_flights;
            list<Flight>::iterator i;

            for (i = flights.begin(); i != flights.end(); i++){
                if (i->flight_date == date){
                    result_flights.push_back(*i);
                }
            }

            return result_flights;
        }

        string toString(){
            ostringstream result;
            list<Flight>::iterator i;

            for (i = flights.begin(); i != flights.end(); i++){
                result << i->flight_number << " " << i->flight_date << " " << i->flight_hour << " " << i->is_cancelled << endl;
            }

            return result.str();
        }

        // void fromString(string flights){
        //     istringstream in(flights);

        //     while (in != endl){
        //         string flight_num << in;
        //         string flight_date << in;
        //         string flight_hour << in;
        //         Flight new_flight = Flight(flight_num, flight_date, flight_hour);
        //         flights.push_back(new_flight);
        //         in.ignore(1);
        //     }
        // }
};

int main(){

    return 0;
}